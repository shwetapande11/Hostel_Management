package com.example.demo.Service;

import com.example.demo.Entity.Organization;

public interface OrganizationService {
	public void addOrganization(Organization o);
	public Organization getOrganizationById(int id);

}
