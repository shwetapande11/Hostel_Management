package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Breakup;

public interface BreakupRepository extends JpaRepository<Breakup, Integer>{

}
