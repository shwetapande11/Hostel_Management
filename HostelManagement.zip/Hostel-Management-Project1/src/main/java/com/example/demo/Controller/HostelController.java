package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Hostel;
import com.example.demo.Service.HostelService;

@RestController
public class HostelController {

	
	@Autowired
	HostelService hostelService;
	
	@PostMapping("addHostel")
    public String addHostel(@RequestBody Hostel h) {
        return hostelService.addHostel(h);
    }
	
	
	 @GetMapping("getHostel/{id}")
	    public List<Hostel> getHostel(@PathVariable int id) {
	        return hostelService.getHostelById(id);
	    }
	
	 @DeleteMapping("delete/{id}")
	    public String deleteHostel(@PathVariable int id) {
	        return hostelService.deleteHostel(id);
	    }
}
