package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Dto.BuildingDto;
import com.example.demo.Dto.FloorDto;
import com.example.demo.Entity.Building;
import com.example.demo.Service.BuildingService;

@RestController

public class BuildingController {

    @Autowired
    private BuildingService buildingService;

    @PostMapping("addBuilding")
    public String addBuilding(@RequestBody BuildingDto dto) {
        buildingService.saveBuilding(dto);
        return"Buiding added";
    }

    @GetMapping("getbuilding/{id}")
    public BuildingDto getBuilding(@PathVariable int id) {
        return buildingService.getBuilding(id);
    }
    
    @GetMapping("AllBuilding")
    public List<BuildingDto> getAllBuilding() {
        return buildingService.getAllBuilding();
    }
}
