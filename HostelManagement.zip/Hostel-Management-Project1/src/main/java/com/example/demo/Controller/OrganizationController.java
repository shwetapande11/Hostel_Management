package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Organization;
import com.example.demo.Service.OrganizationService;

@RestController
public class OrganizationController {

@Autowired
OrganizationService organizationService;
	
	@PostMapping("addOrganization")
	public String addOrganization(@RequestBody Organization o)
	{
		organizationService.addOrganization(o);
		return "organization added";
	}
	
	
	@GetMapping("org/{id}")
	public Organization getOrganizationById(@PathVariable int id)
	{
		return organizationService.getOrganizationById(id);
		
	}

}
