package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Dto.FloorDto;
import com.example.demo.Service.FloorService;

@RestController

public class FloorController {

    @Autowired
     FloorService floorService;

  

   
    @PostMapping("addFloor")
    public String addFloor(@RequestBody FloorDto dto) {
         floorService.addFloor(dto);
         return "Floors Added";
    }

    
    @GetMapping("AllFloor")
    public List<FloorDto> getAllFloors() {
        return floorService.getAllFloor();
    }

  
    @GetMapping("Floor/{id}")
    public FloorDto getFloorById(@PathVariable int id) {
        return floorService.getFloorById(id);
    }
}