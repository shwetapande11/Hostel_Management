package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dto.BookingDto;
import com.example.demo.Entity.Booking;
import com.example.demo.Service.BookingService;

@RestController
public class BookingController {

	@Autowired
	BookingService bookingService;

	@PostMapping("AddBooking")
	public String saveBooking(@RequestBody BookingDto dto) {

		bookingService.equals(dto);
		return "Booking Done";
	}

	@GetMapping("getBooking/{id}")
	public Booking getBooking(@PathVariable int id) {
		return bookingService.getBooking(id);
	}
}
