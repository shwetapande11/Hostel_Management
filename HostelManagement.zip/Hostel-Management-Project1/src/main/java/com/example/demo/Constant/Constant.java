package com.example.demo.Constant;

public class Constant {
	public static final String ORGANIZATION_SAVED="ORGANIZATION SAVED SUCCESSFULLY.";
	public static final String HOSTEL_SAVED="HOSTEL SAVED SUCCESSFULLY.";
	public static final String BUILDING_SAVED="BUILDING SAVED SUCCESSFULLY.";
	public static final String FLOOR_SAVED="FLOOR SAVED SUCCESSFULLY.";
	public static final String ROOM_SAVED="ROOM SAVED SUCCESSFULLY.";
	public static final String BED_SAVED="BED SAVED SUCCESSFULLY.";
	public static final String USER_SAVED="USER SAVED SUCCESSFULLY";
	public static final String USER_DELETE="USER DELETED SUCCESSFULLY";
	public static final String ALL_USER_DELETE="ALL USER DELETED SUCCESSFULLY";
	
	public static final String BED_DELETED = "BED DELETED SUCCESSFULLY.";
	public static final String ALL_BEDS_DELETED = "ALL BEDS DELETED SUCCESSFULLY.";
	

}



