package com.example.demo.Service;

import java.util.List;

import com.example.demo.Dto.bedDto;
import com.example.demo.Entity.Bed;

public interface BedService {

    String addBed(bedDto dto);

    Bed getBed(int id);

    List<bedDto> getAllBeds();

    List<bedDto> getVacantBeds(int hostelId);

    List<bedDto> getBedsBySharingAndStatus(int sharing, String status);
}

	
	
