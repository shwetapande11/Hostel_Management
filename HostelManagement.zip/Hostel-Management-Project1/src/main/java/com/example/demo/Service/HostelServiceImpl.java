package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Hostel;
import com.example.demo.Repository.HostelRepository;

@Service
public class HostelServiceImpl implements HostelService
{

	
	@Autowired
	HostelRepository hostelRepository;

	@Override
	public String addHostel(Hostel h) {
		hostelRepository.save(h);
		return "Hostel Added";
	}

	

	@Override
	public String deleteHostel(int id) {
		hostelRepository.deleteById(id);
		return "hostel deleted";
	}

	@Override
	public List<Hostel> getHostelById(int id) {
		hostelRepository.findById(id).get();
		return null;
	}
	
	
	
}
