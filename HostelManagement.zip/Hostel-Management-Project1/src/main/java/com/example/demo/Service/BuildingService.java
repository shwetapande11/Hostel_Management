package com.example.demo.Service;

import java.util.List;

import com.example.demo.Dto.BuildingDto;
import com.example.demo.Dto.FloorDto;
import com.example.demo.Entity.Building;

public interface BuildingService {

	 String saveBuilding(BuildingDto dto);

	    BuildingDto getBuilding(int id);
	    public List<BuildingDto> getAllBuilding();
	    
}
