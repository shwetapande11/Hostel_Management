package com.example.demo.RazorPay;

public class PaymentDto {

    private double amount;
    private String currency;
    private String orderId;
    private String paymentId;
    private String signature;
    
  
    private Integer bookingId;

	public Integer getBookingId() {
	    return bookingId;
	}
	public void setBookingId(Integer bookingId) {
	    this.bookingId = bookingId;
	}

    
    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
        
        
    }

}