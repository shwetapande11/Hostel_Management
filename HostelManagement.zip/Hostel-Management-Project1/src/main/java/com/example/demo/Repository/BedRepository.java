package com.example.demo.Repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.Entity.Bed;

public interface BedRepository extends JpaRepository<Bed, Integer>{

	List<Bed> findByRoom_Floor_Building_Hostel_Id(int hostelId);

	@Query("SELECT b FROM Bed b WHERE b.status = :status AND b.room.floor.building.hostel.id = :hostelId")
    List<Bed> findByStatusAndHostel(String status, int hostelId);
	
	 @Query("SELECT b FROM Bed b WHERE b.room.sharing = :sharing AND b.status = :status")
	    List<Bed> findBySharingAndStatus(int sharing, String status);
	
}
