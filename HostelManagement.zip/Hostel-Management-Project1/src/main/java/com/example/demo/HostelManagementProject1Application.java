package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostelManagementProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(HostelManagementProject1Application.class, args);
	}

}
