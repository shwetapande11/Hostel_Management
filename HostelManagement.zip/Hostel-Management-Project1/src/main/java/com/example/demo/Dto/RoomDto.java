package com.example.demo.Dto;

public class RoomDto {
    private int roomNo;
    private int sharing;
    private String type;
    private int floorId;
    private int NoOfbed;
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public int getSharing() {
		return sharing;
	}
	public void setSharing(int sharing) {
		this.sharing = sharing;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getFloorId() {
		return floorId;
	}
	public void setFloorId(int floorId) {
		this.floorId = floorId;
	}
	public int getNoOfbed() {
		return NoOfbed;
	}
	public void setNoOfbed(int noOfbed) {
		NoOfbed = noOfbed;
	}
    
    
    
}
