package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Dto.BreakupDto;
import com.example.demo.Entity.Breakup;
import com.example.demo.Service.BreakupService;

@RestController
public class BreakupController {

	@Autowired
	BreakupService breakupService;
	
	@PostMapping("addBreakup")
	public String addBreakup(@RequestBody BreakupDto dto)
	{
		breakupService.saveBreakup(dto);
	
	       return "added";
	}
	
	
	@GetMapping("getBreakup/{id}")
	public Breakup getBreakup(@PathVariable int id) 
	{
	    return breakupService.getBreakup(id);
	}
	
	
	
}