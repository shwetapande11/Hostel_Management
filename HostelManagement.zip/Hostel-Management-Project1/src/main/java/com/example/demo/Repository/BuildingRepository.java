package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Building;

public interface BuildingRepository extends JpaRepository<Building, Integer>{

}
