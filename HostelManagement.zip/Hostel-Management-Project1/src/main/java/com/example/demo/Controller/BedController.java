package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Dto.bedDto;
import com.example.demo.Entity.Bed;
import com.example.demo.Service.BedService;

@RestController


public class BedController {

    @Autowired
    private BedService bedService;


    @PostMapping("addBed")
    public String addBed(@RequestBody bedDto dto) {
        bedService.addBed(dto);
        return "Bed Added";
    }


    @GetMapping("bed/{id}")
    public Bed getBed(@PathVariable int id) {
        return bedService.getBed(id);
    }


    @GetMapping("allBed")
    public List<bedDto> getAllBeds() {
        return bedService.getAllBeds();
    }

    @GetMapping("vacant/{hostelId}")
    public List<bedDto> getVacantBeds( @PathVariable int hostelId) {
        return bedService.getVacantBeds (hostelId);
    }

    @GetMapping("filter/by-sharing")
    public List<bedDto> getBedsBySharingAndStatus( @RequestParam int sharing,@RequestParam String status)
        {

        return bedService.getBedsBySharingAndStatus(sharing, status);
    }
}
