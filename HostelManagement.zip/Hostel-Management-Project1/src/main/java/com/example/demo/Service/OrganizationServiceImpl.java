package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Organization;
import com.example.demo.Repository.OrganizationRepository;
@Service
public class OrganizationServiceImpl implements OrganizationService{

	@Autowired
	OrganizationRepository organizationRepository;
	@Override
	public void addOrganization(Organization o) {
		// TODO Auto-generated method stub
		organizationRepository.save(o);
		
		
	}

	@Override
	public Organization getOrganizationById(int id) {
		// TODO Auto-generated method stub
	return	organizationRepository.findById(id).get();
		
		
	}

}
