package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Room;

public interface RoomRepository extends JpaRepository<Room, Integer>{

	
	 
	    List<Room> findByFloorId(Integer floorId);
}
