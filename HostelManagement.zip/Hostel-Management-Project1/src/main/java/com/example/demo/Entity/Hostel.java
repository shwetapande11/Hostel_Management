package com.example.demo.Entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Hostel {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String adddress;
	 private Integer capacity;
	    private String contactNo;
	    private String type;
	    private String image;
	    private String website;
	    
	    @ManyToOne
	    @JoinColumn(name = "organization_id")
	    private Organization organization;
	    
	    @OneToMany(cascade = CascadeType.ALL)
	    @JoinColumn(name = "hostel_id")
	    private List<Building> Building;


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}
 

		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getAdddress() {
			return adddress;
		}


		public void setAdddress(String adddress) {
			this.adddress = adddress;
		}


		public Integer getCapacity() {
			return capacity;
		}


		public void setCapacity(Integer capacity) {
			this.capacity = capacity;
		}


		public String getContactNo() {
			return contactNo;
		}


		public void setContactNo(String contactNo) {
			this.contactNo = contactNo;
		}


		public String getType() {
			return type;
		}


		public void setType(String type) {
			this.type = type;
		}


		public String getImage() {
			return image;
		}


		public void setImage(String image) {
			this.image = image;
		}


		public String getWebsite() {
			return website;
		}


		public void setWebsite(String website) {
			this.website = website;
		}


		public List<Building> getBuilding() {
			return Building;
		}


		public void setBuilding(List<Building> building) {
			Building = building;
		}
	    
	    
	
}
