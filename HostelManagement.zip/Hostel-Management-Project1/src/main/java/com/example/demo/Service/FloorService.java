package com.example.demo.Service;

import java.util.List;

import com.example.demo.Dto.FloorDto;
import com.example.demo.Entity.Floors;


public interface FloorService {

  public  void addFloor(FloorDto dto);
    public List<FloorDto> getAllFloor();
   public  FloorDto getFloorById(int id);
}
