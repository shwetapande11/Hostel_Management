package com.example.demo.Service;

import java.util.List;

import com.example.demo.Dto.RoomDto;
import com.example.demo.Entity.Room;

public interface RoomService {
	
	 String addRooms(List<RoomDto> roomDtos);
	    Room getRoom(int id);
	    List<RoomDto> getAllRooms();
	    List<Room> findByFloorId(Integer floorId);
	}
