package com.example.demo.Service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dto.BookingDto;

import com.example.demo.Entity.Bed;
import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Payment;
import com.example.demo.Entity.User;
import com.example.demo.Repository.BedRepository;
import com.example.demo.Repository.BookingRepository;
import com.example.demo.Repository.PaymentRepository;
import com.example.demo.Repository.UserRepository;


@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	BookingRepository bookingRepository;

	@Autowired
	BedRepository bedRepository;

	@Override
	public void saveBooking(BookingDto dto) {
		// TODO Auto-generated method stub
		Bed bed = bedRepository.findById(dto.getBedId()).get();

		Booking b = new Booking();
		b.setStatus(dto.getStatus());
	
		b.setBed(bed);
		bookingRepository.save(b);

	}

	@Override
	public Booking getBooking(int id) {
		// TODO Auto-generated method stub
		return bookingRepository.findById(id).get();
	}

	@Override
	public void updateBooking(int bookingId, long transactionId, boolean success, long orderId) {
		// TODO Auto-generated method stub
		
	}
}



//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.Dto.BookingDto;
//import com.example.demo.Entity.Bed;
//import com.example.demo.Entity.Booking;
//import com.example.demo.Repository.BedRepository;
//import com.example.demo.Repository.BookingRepository;

//@Service
//public class BookingServiceImpl implements BookingService{
//	@Autowired
//    BookingRepository bookingRepository;
//
//    @Autowired
//    PaymentRepository paymentRepository;
//
//    @Autowired
//    BedRepository bedRepository;
//    
//    @Autowired
//    UserRepository userRepository;
//
//    @Override
//    public BookingDto createBooking(BookingDto dto) {
//
//        Bed bed = bedRepository.findById(dto.getBedId())
//        		 .orElseThrow(() -> new RuntimeException("Bed not found with id: " + dto.getBedId()));
//        User user = userRepository.findById(dto.getUserId())
//        		 .orElseThrow(() -> new RuntimeException("User not found with id: " + dto.getUserId()));
//  
//        Booking booking = new Booking();
//        booking.setBed(bed);
//        booking.setUser(user);
//        booking.setEndDate(dto.getEndDate());
//        booking.setFinalPrice(dto.getFinalPrice());
//        booking.setStatus(dto.getStatus());
//        booking.setStartDate(LocalDateTime.now());
//
//        Booking savedBooking = bookingRepository.save(booking);
//
//   
//        Payment payment = new Payment();
//        payment.setBooking(savedBooking);
//        payment.setStatus("PENDING");
//
//        Payment savedPayment = paymentRepository.save(payment);
//
//        // Link payment back to booking
//        savedBooking.setPayment(savedPayment);
//        bookingRepository.save(savedBooking);
//
//    
//        BookingDto bookingdto  = new BookingDto();
//        bookingdto.setUserId(savedBooking.getUser().getId());
//        bookingdto.setBedId(savedBooking.getBed().getId());
//        bookingdto.setStartDate(savedBooking.getStartDate());
//        bookingdto.setEndDate(savedBooking.getEndDate());
//        bookingdto.setFinalPrice(savedBooking.getFinalPrice());
//        bookingdto.setStatus(savedBooking.getStatus());
//
//       
//        PaymentDto paymentDto = new PaymentDto();
//       
//        paymentDto.setOrderId(savedPayment.getOrderId());
//        paymentDto.setTransactionId(savedPayment.getTransactionId());
//        paymentDto.setSuccess(savedPayment.getStatus().equals("SUCCESS"));
//
//        bookingdto.setPayment(paymentDto);
//
//        return bookingdto;
//    }
// 
//      
//}
//    


//    @Override
//    public void updateBooking(int bookingId, long transactionId, boolean success, long orderId) {
//
//        Booking booking = bookingRepository.findById(bookingId).get();
//        Payment payment = paymentRepository.findByTransactionId(booking.getPayment().getTransactionId()).get();
//        User user = userRepository.findById(booking.getUserId()).get();    
//        Bed bed = booking.getBed();
//        payment.setTransactionId(transactionId);
//        payment.setOrderId(orderId);
//
//        if (success) {
//            payment.setStatus("SUCCESS");
//            booking.setStatus("CONFIRMED");
//         
//            user.setBed(bed);
//            userRepository.save(user);
//        } else {
//            payment.setStatus("FAILED");
//            booking.setStatus("CANCELLED");
//          
//          
//            userRepository.save(user);
//        }
//
//        bedRepository.save(bed);
//        paymentRepository.save(payment);
//        bookingRepository.save(booking);
//    }
//
//
//}
