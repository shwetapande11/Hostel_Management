package com.example.demo.Dto;

import com.example.demo.Entity.Payment;



public class BookingDto {
	private int bedId;
	private String status;
	private int userId;
	private String paymentStatus;
	
	
	private Payment payment;
	
	private int booking_Id;
	public int getBedId() {
		return bedId;
	}
	public void setBedId(int bedId) {
		this.bedId = bedId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	public int getBooking_Id() {
		return booking_Id;
	}
	public void setBooking_Id(int booking_Id) {
		this.booking_Id = booking_Id;
	}
	
	
}

//package com.example.demo.Dto;
//
//import java.time.LocalDateTime;
//
//public class BookingDto {
//
//	private int userId;
//    private int bedId;
//    private int finalPrice;
//    
//    private PaymentDto payment;
//    
//    
//    public int getFinalPrice() {
//		return finalPrice;
//		
//		
//	}
//	public void setFinalPrice(int finalPrice) {
//		this.finalPrice = finalPrice;
//	}
//	public String getStatus() {
//		return status;
//	}
//	public void setStatus(String status) {
//		this.status = status;
//	}
//	public LocalDateTime getStartDate() {
//		return startDate;
//	}
//	public void setStartDate(LocalDateTime startDate) {
//		this.startDate = startDate;
//	}
//	public LocalDateTime getEndDate() {
//		return endDate;
//	}
//	public void setEndDate(LocalDateTime endDate) {
//		this.endDate = endDate;
//	}
//	private String status;
//    private LocalDateTime startDate;
//    private LocalDateTime endDate;
//    
//	public int getUserId() {
//		return userId;
//	}
//	public void setUserId(int userId) {
//		this.userId = userId;
//	}
//	public int getBedId() {
//		return bedId;
//	}
//	public void setBedId(int bedId) {
//		this.bedId = bedId;
//	}
//	public PaymentDto getPayment() {
//		return payment;
//	}
//	public void setPayment(PaymentDto payment) {
//		this.payment = payment;
//	}
//	
//	
//}
