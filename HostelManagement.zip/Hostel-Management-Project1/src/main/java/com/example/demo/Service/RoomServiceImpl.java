package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dto.RoomDto;
import com.example.demo.Entity.Bed;
import com.example.demo.Entity.Floors;
import com.example.demo.Entity.Room;
import com.example.demo.Repository.FloorRepository;
import com.example.demo.Repository.RoomRepository;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private FloorRepository floorRepository;

    @Override
    public String addRooms(List<RoomDto> roomDtos) {
        for (RoomDto dto : roomDtos) {
            Floors floor = floorRepository.findById(dto.getFloorId()).get();
          

            Room room = new Room();
            room.setRoomNo(dto.getRoomNo());
            room.setSharing(dto.getSharing());
            room.setType(dto.getType());
            room.setFloor(floor);

           
            List<Bed> beds = new ArrayList<>();
            for (int i = 1; i <= dto.getNoOfbed(); i++) {
                Bed bed = new Bed();
                bed.setBedNo(i);
                bed.setStatus("A"); 
             
                bed.setRoom(room);
                beds.add(bed);
            }

           
            roomRepository.save(room);
        }
        return "Rooms added successfully!";
    }

    @Override
    public Room getRoom(int id) {
        return roomRepository.findById(id).get();
                
    }

    @Override
    public List<RoomDto> getAllRooms() {
        List<Room> rooms = roomRepository.findAll();
       
        
        
        List<RoomDto> lrdto = new ArrayList<>();

        for (Room room : rooms) {
            RoomDto dto = new RoomDto();
         
            dto.setRoomNo(room.getRoomNo());
            dto.setSharing(room.getSharing());
            dto.setType(room.getType());
            dto.setFloorId(room.getFloor().getId());
          
            lrdto.add(dto);
        }

        return lrdto;
    }

	@Override
	public List<Room> findByFloorId(Integer floorId) {
		// TODO Auto-generated method stub
		return null;
	}

	
		
				
	}



