package com.example.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dto.BreakupDto;
import com.example.demo.Entity.Breakup;
import com.example.demo.Repository.BreakupRepository;
@Service
public class BreakupServiceImpl implements BreakupService {
@Autowired
BreakupRepository breakupRepository; 
	@Override
	public void saveBreakup(BreakupDto dto) {
		// TODO Auto-generated method stub
		Breakup bp = new Breakup();
		bp.setDuration(dto.getDuration());
		bp.setName(dto.getName());
		bp.setPaymentStatus(dto.getPaymentStatus());
		bp.setName(dto.getName());
		
		breakupRepository.save(bp);
		
			
		
	}

	@Override
	public Breakup getBreakup(int id) {
		// TODO Auto-generated method stub
		return breakupRepository.findById(id).get();
		
	}

}
