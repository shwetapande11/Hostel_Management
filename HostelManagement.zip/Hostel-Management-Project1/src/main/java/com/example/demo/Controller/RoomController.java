package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Dto.RoomDto;
import com.example.demo.Entity.Room;
import com.example.demo.Service.RoomService;

@RestController

public class RoomController {

    @Autowired
     RoomService roomService;

    @PostMapping("addRoom")
    public String addRooms(@RequestBody List<RoomDto> roomDtos) {
       roomService.addRooms(roomDtos);
       return "room added";
    }

    @GetMapping("getRoom/{id}")
    public Room getRoom(@PathVariable int id) {
        return roomService.getRoom(id);
    }

    @GetMapping("getall")
    public List<RoomDto> getAllRooms() {
        return roomService.getAllRooms();
    }
}
