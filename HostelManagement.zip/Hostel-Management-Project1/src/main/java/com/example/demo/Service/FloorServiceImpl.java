package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dto.FloorDto;

import com.example.demo.Entity.Building;
import com.example.demo.Entity.Floors;

import com.example.demo.Repository.BuildingRepository;
import com.example.demo.Repository.FloorRepository;

@Service
public class FloorServiceImpl implements FloorService {

	@Autowired
	private BuildingRepository buildingRepository;

	@Autowired
	private FloorRepository floorRepository;

	@Override
	public void addFloor(FloorDto dto) {

		Building building = buildingRepository.findById(dto.getBuildingId()).get();

		Floors f = new Floors();

	    f.setFloorNo(dto.getFloorNo());
		f.setNoRooms(dto.getNoOfRooms());
		f.setBuilding(building);

		floorRepository.save(f);
		
		
	}

	@Override
	public List<FloorDto> getAllFloor() {
		List<Floors> floor = floorRepository.findAll();
		List<FloorDto> lfdto = new ArrayList<>();

		for (Floors f : floor) {

			FloorDto dto = new FloorDto();
			dto.setFloorNo(f.getFloorNo());
			
			dto.setNoOfRooms(f.getNoRooms());
			dto.setBuildingId(0);
			

			lfdto.add(dto);

		}
		return lfdto;

	}

	
	@Override
	public FloorDto getFloorById(int id) {
	Floors f =	floorRepository.findById(id).get();
		
		 FloorDto dto = new FloorDto();
		    dto.setFloorNo(f.getFloorNo());
		    dto.setNoOfRooms(f.getNoRooms());
		  
		    return dto;
	}
	
	
}

