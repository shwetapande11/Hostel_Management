package com.example.demo.Service;

import java.util.List;

import com.example.demo.Entity.Hostel;

public interface HostelService {

	
	public String addHostel(Hostel h);
	public List<Hostel> getHostelById(int id);
	public String deleteHostel(int id);
}
