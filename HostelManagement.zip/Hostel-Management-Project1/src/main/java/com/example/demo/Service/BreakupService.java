package com.example.demo.Service;

import com.example.demo.Dto.BreakupDto;
import com.example.demo.Entity.Breakup;

public interface BreakupService {

	public void saveBreakup(BreakupDto dto);
	public Breakup getBreakup(int id);
	
}
