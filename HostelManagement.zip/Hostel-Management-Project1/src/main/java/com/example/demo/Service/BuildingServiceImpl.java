package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dto.BuildingDto;
import com.example.demo.Dto.FloorDto;
import com.example.demo.Entity.Building;
import com.example.demo.Entity.Floors;
import com.example.demo.Entity.Hostel;
import com.example.demo.Repository.BuildingRepository;
import com.example.demo.Repository.HostelRepository;


@Service
public class BuildingServiceImpl implements BuildingService {

	
	@Autowired 
BuildingRepository buildingRepository;
	
	@Autowired
	HostelRepository hostelRepository;
	
	@Override
	
	
	public String saveBuilding(BuildingDto dto) {
		// TODO Auto-generated method stub
		
		Hostel hostel = hostelRepository.findById(dto.getHostelId())
		        .orElseThrow(() -> new RuntimeException("Hostel not found!"));

		

		
		
		 Building building = new Building();
		    building.setName(dto.getName());
		    building.setWarden(dto.getWarden());
		    building.setNoOfFloors(dto.getNoOfFloors());
		    building.setHostel(hostel);
        buildingRepository.save(building);

        return "Building Added Successfully";
    }

	@Override
	public BuildingDto getBuilding(int id) {
		Building building =	buildingRepository.findById(id).get();
		
		 BuildingDto dto = new  BuildingDto();
		    dto.setNoOfFloors(building.getNoOfFloors());
		    dto.setHostelId(building.getId());
		    dto.setWarden(building.getWarden());
		    dto.setName(building.getName());
		  
		    return dto;
	}
	

	@Override
	public List<BuildingDto> getAllBuilding() {
		// TODO Auto-generated method stub
		List<Building> buildings = buildingRepository.findAll();
				List<BuildingDto> lbDto = new ArrayList<>();
		for(Building b:buildings)
		{
			BuildingDto dto = new BuildingDto();
			dto.setNoOfFloors(b.getNoOfFloors());
			dto.setWarden(b.getWarden());
			dto.setName(b.getName());
			dto.setWarden(b.getWarden());
			dto.setHostelId(0);
			
		}
		return null;
	}
}
    

