package com.example.demo.Repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.NativeQuery;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.Entity.Hostel;

public interface HostelRepository extends JpaRepository<Hostel, Integer> {

	
}
