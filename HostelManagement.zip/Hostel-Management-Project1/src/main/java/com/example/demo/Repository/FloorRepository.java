package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.Entity.Floors;

public interface FloorRepository extends JpaRepository<Floors, Integer>{

}
