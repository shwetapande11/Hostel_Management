package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Dto.bedDto;
import com.example.demo.Entity.Bed;
import com.example.demo.Entity.Building;
import com.example.demo.Entity.Floors;
import com.example.demo.Entity.Room;
import com.example.demo.Repository.BedRepository;
import com.example.demo.Repository.RoomRepository;

@Service
public class bedServiceImpl implements BedService {

    @Autowired
    private RoomRepository roomRepository;

    @Autowired
    private BedRepository bedRepository;




    @Override
    public String addBed(bedDto dto) {

        Room room = roomRepository.findById(dto.getRoomId())
                .orElseThrow(() -> new RuntimeException("Room Not Found"));

        Bed bed = new Bed();
        bed.setBedNo(dto.getBedNo());
        bed.setPrice(dto.getPrice());
        bed.setStatus(dto.getStatus());
        bed.setRoom(room);

        bedRepository.save(bed);

        return "Bed Added Successfully";
    }


    @Override
    public Bed getBed(int id) {
        return bedRepository.findById(id).orElse(null);
    }



    @Override
    public List<bedDto> getAllBeds() {
    	 Room room = roomRepository.findAll().get(0);
        List<Bed> beds = bedRepository.findAll();
        List<bedDto> list = new ArrayList<>();

        for (Bed bed : beds) {

            Room r = bed.getRoom();
            Floors f = r.getFloor();
            Building b = f.getBuilding();

            bedDto dto = new bedDto();
            dto.setBedNo(bed.getBedNo());
            dto.setStatus(bed.getStatus());
            dto.setPrice(bed.getPrice());
            

          
            dto.setFloorNo(f.getFloorNo());
            dto.setBuildingName(b.getName());
            dto.setHostelName(b.getHostel().getName());

            list.add(dto);
        }

        return list;
    }



    @Override
    public List<bedDto> getBedsBySharingAndStatus(int sharing, String status) {

        List<Bed> beds = bedRepository.findBySharingAndStatus(sharing, status);
        List<bedDto> list = new ArrayList<>();

        for (Bed bed : beds) {

            Room r = bed.getRoom();
            Floors f = r.getFloor();
            Building b = f.getBuilding();

            bedDto dto = new bedDto();
            dto.setBedNo(bed.getBedNo());
            dto.setStatus(bed.getStatus());
            dto.setPrice(bed.getPrice());

            
            dto.setFloorNo(f.getFloorNo());
            dto.setBuildingName(b.getName());
            dto.setHostelName(b.getHostel().getName());

            list.add(dto);
        }

        return list;
    }


	@Override
	public List<bedDto> getVacantBeds(int hostelId) {
		// TODO Auto-generated method stub
		 List<Bed> beds = bedRepository.findByStatusAndHostel("VACANT", hostelId);
	        List<bedDto> lbDto = new ArrayList<>();

	        for (Bed bed : beds) {
	       
	        	
	            Room r = bed.getRoom();
	            Floors f = r.getFloor();
	            Building b = f.getBuilding();

	            bedDto dto = new bedDto();
	            dto.setBedNo(bed.getBedNo());
	            dto.setStatus(bed.getStatus());
	            dto.setPrice(bed.getPrice());

	            dto.setRoomNo(bed.getRoom().getRoomNo());
	            dto.setFloorNo(bed.getRoom().getFloor().getFloorNo());
	            dto.setBuildingName(bed.getRoom().getFloor().getBuilding().getName());
	            dto.setHostelName(bed.getRoom().getFloor().getBuilding().getName()
	            		);

	            lbDto.add(dto);
	        }

	        return lbDto ;
	    }


	}

	