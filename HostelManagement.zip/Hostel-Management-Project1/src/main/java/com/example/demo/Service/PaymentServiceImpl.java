package com.example.demo.Service;

import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Payment;
import com.example.demo.RazorPay.PaymentDto;
import com.example.demo.RazorPay.PaymentService;
import com.example.demo.Repository.BookingRepository;
import com.example.demo.Repository.PaymentRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@Service
public class PaymentServiceImpl implements PaymentService {

	 private final BookingRepository bookingRepo;
    @Value("${razorpay.key}")
    private String razorpayKey;

    @Value("${razorpay.secret}")
    private String razorpaySecret;

    private final PaymentRepository paymentRepo;
   
    
 

    public PaymentServiceImpl(PaymentRepository paymentRepo,
            BookingRepository bookingRepository) {
this.paymentRepo = paymentRepo;
this.bookingRepo = bookingRepository;
}

    @Override
    public Payment createOrder(PaymentDto dto) {
    	try {
            RazorpayClient client = new RazorpayClient(razorpayKey, razorpaySecret);

            JSONObject request = new JSONObject();
            request.put("amount", (int)(dto.getAmount() * 100));
            request.put("currency", dto.getCurrency());
            request.put("receipt", "txn_" + System.currentTimeMillis());

            Order order = client.orders.create(request);

            Payment payment = new Payment();
            payment.setOrderId(order.get("id"));
            payment.setAmount(dto.getAmount());
            payment.setCurrency(dto.getCurrency());
            payment.setStatus("CREATED");

            // ✅ SET booking
            if (dto.getBookingId() != null) {
                Booking booking = bookingRepo.findById(dto.getBookingId()).orElse(null);
                payment.setBooking(booking);
            }

            return paymentRepo.save(payment);

        } catch (Exception e) {
            throw new RuntimeException("Order creation failed: " + e.getMessage());
        }
    }

    @Override
    public Payment verifyPayment(PaymentDto dto) {
    	  Payment payment = paymentRepo.findByOrderId(dto.getOrderId());
          if (payment == null) throw new RuntimeException("Payment not found with orderId: " + dto.getOrderId());

          try {
              String generatedSignature = generateSignature(dto.getOrderId(), dto.getPaymentId(), razorpaySecret);

              if (generatedSignature.equals(dto.getSignature())) {
                  payment.setStatus("SUCCESS");
                  payment.setPaymentId(dto.getPaymentId());
                  payment.setSignature(dto.getSignature());
              } else {
                  payment.setStatus("FAILED");
              }

              return paymentRepo.save(payment);

          } catch (Exception e) {
              throw new RuntimeException("Verification failed: " + e.getMessage(), e);
          }
      }

      private String generateSignature(String orderId, String paymentId, String secret) throws Exception {
          String data = orderId + "|" + paymentId;
          Mac mac = Mac.getInstance("HmacSHA256");
          SecretKeySpec keySpec = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
          mac.init(keySpec);
          byte[] hash = mac.doFinal(data.getBytes());
          return bytesToHex(hash);
      }

      private String bytesToHex(byte[] hash) {
          StringBuilder hexString = new StringBuilder();
          for (byte b : hash) {
              String hex = Integer.toHexString(0xff & b);
              if (hex.length() == 1) hexString.append('0');
              hexString.append(hex);
          }
          return hexString.toString();
      }
  }