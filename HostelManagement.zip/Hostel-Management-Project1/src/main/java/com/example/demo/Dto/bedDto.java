package com.example.demo.Dto;

public class bedDto {

	
 
	 private int roomId;
	    private int bedNo;
	    private int price;
	    private String status;
	    

	  
	    private int roomNo;
	    private int floorNo;
	    private String buildingName;
	    private String hostelName;
		public int getRoomId() {
			return roomId;
		}
		public void setRoomId(int roomId) {
			this.roomId = roomId;
		}
		public int getBedNo() {
			return bedNo;
		}
		public void setBedNo(int bedNo) {
			this.bedNo = bedNo;
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			this.price = price;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public int getRoomNo() {
			return roomNo;
		}
		public void setRoomNo(int roomNo) {
			this.roomNo = roomNo;
		}
		public int getFloorNo() {
			return floorNo;
		}
		public void setFloorNo(int floorNo) {
			this.floorNo = floorNo;
		}
		public String getBuildingName() {
			return buildingName;
		}
		public void setBuildingName(String buildingName) {
			this.buildingName = buildingName;
		}
		public String getHostelName() {
			return hostelName;
		}
		public void setHostelName(String hostelName) {
			this.hostelName = hostelName;
		}
	    
}	