package com.example.demo.Service;

import com.example.demo.Dto.BookingDto;
import com.example.demo.Entity.Booking;

public interface BookingService {

	public void saveBooking(BookingDto dto);
	public Booking getBooking(int id);


	
	public void updateBooking(int bookingId, long transactionId, boolean success, long orderId);

	}