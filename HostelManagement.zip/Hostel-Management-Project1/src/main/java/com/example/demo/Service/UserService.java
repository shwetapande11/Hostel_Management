package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import com.example.demo.Dto.UserDto;
import com.example.demo.Entity.User;


public interface UserService {

	public void saveUser(UserDto userDto);

	public List<UserDto> getAllUsers();

	UserDto getUserById(int id);

	void deleteUser(int id);

	void deleteAllUsers();
}


