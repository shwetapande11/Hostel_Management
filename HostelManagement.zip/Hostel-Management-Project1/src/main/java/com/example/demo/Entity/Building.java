package com.example.demo.Entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Building {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int id;

    private String name;
    private String warden;
   
    private Integer NoOfFloors;

	
    @ManyToOne
    @JoinColumn(name = "hostel_id")
    private Hostel hostel;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "building_id")
	private List<Floors> floors;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWarden() {
		return warden;
	}

	public void setWarden(String warden) {
		this.warden = warden;
	}

	public List<Floors> getFloors() {
		return floors;
	}

	public void setFloors(List<Floors> floors) {
		this.floors = floors;
	}

	public Hostel getHostel() {
		return hostel;
	}

	public void setHostel(Hostel hostel) {
		this.hostel = hostel;
	}

	public int getNoOfFloors() {
		return NoOfFloors;
	}

	public void setNoOfFloors(int noOfFloors) {
	    this.NoOfFloors = noOfFloors;
	}


	
	}


