package com.example.demo.Entity;



import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
@Entity
public class Organization {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	private String name;
	private String address;
	private int moNO;
	
	
	@OneToMany(mappedBy = "organization", cascade = CascadeType.ALL)
    private List<Hostel> hostels;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public int getMoNO() {
		return moNO;
	}


	public void setMoNO(int moNO) {
		this.moNO = moNO;
	}


	public List<Hostel> getHostels() {
		return hostels;
	}


	public void setHostels(List<Hostel> hostels) {
		this.hostels = hostels;
	}
	
	

}
