package com.example.demo.RazorPay;

import com.example.demo.Entity.Payment;

public interface PaymentService {
    Payment createOrder(PaymentDto dto);
    Payment verifyPayment(PaymentDto dto);
}
