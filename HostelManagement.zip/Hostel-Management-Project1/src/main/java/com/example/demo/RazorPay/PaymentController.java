package com.example.demo.RazorPay;

import com.example.demo.Entity.Payment;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/create-order")
    public Payment createOrder(@RequestBody PaymentDto dto) {
        return paymentService.createOrder(dto);
    }

    @PostMapping("/verify")
    public Payment verifyPayment(@RequestBody PaymentDto dto) {
        return paymentService.verifyPayment(dto);
    }
}
